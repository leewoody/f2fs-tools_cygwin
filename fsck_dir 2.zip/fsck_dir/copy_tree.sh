#!/bin/bash

# Copy the complete directory tree to the output file
cp ../complete_directory_tree.txt complete_fsck_dir_directory_treev2.txt

echo "Generated complete_fsck_dir_directory_treev2.txt"